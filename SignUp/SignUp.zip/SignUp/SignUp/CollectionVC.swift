//
//  CollectionVC.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.
//

import UIKit
import Photos
import Alamofire
import AlamofireImage

class CollectionVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var collection: UICollectionView!
    var arrayImageOptions = [Dictionary<String,String>]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetArray()
        collection.register(UINib(nibName: "CollectionVCCell", bundle: nil), forCellWithReuseIdentifier: "CollectionVCCell")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        super.viewWillAppear(animated)
    }

    //MARK: CollectionView Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return arrayImageOptions.count;
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        var cell:CollectionVCCell? = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionVCCell", for: indexPath) as? CollectionVCCell
        
        if (cell == nil) {
            let nib: NSArray = Bundle.main.loadNibNamed("CollectionVCCell", owner: self, options: nil)! as NSArray
            cell = (nib.object(at: 0) as? CollectionVCCell)!
        }
        cell?.likeButton.addTarget(self, action: #selector(self.BTClicked), for: .touchUpInside)
        let image = UIImage(named: "heart")!.withRenderingMode(.alwaysTemplate)
        if(arrayImageOptions[indexPath.row]["like"] == "0"){
            cell?.likeButton.setImage(image, for: .normal)
            cell?.likeButton.tintColor = UIColor.gray
        }else{
            cell?.likeButton.setImage(image, for: .normal)
            cell?.likeButton.tintColor = UIColor.red
        }
        cell?.initObject(imageArray: arrayImageOptions[indexPath.row], indexPath: indexPath)
        return cell!
    }
    
    //MARK: touchUpInside Method
    @IBAction func BTClicked(_ sender: Any) {
        let btn = (sender as! UIButton)
        let indexpath: NSIndexPath = NSIndexPath(item: (btn.superview?.tag)!, section: 0)
        let vell = collection.cellForItem(at: indexpath as IndexPath) as! CollectionVCCell
        vell.likeButton.isSelected = true
        if(arrayImageOptions[indexpath.row]["like"] == "0"){
            let image = UIImage(named: "heart")!.withRenderingMode(.alwaysTemplate)
            arrayImageOptions[indexpath.row]["like"]! = "1"
            btn.setImage(image, for: .normal)
            btn.tintColor = UIColor.red
            Comman().animateButton(button: btn)
        }else{
            let image = UIImage(named: "heart")!.withRenderingMode(.alwaysTemplate)
            arrayImageOptions[indexpath.row]["like"]! = "0"
            btn.setImage(image, for: .normal)
            btn.tintColor = UIColor.gray
            //Comman().animateButton(button: btn)
        }
    }
    func SetArray(){
        arrayImageOptions.append(["image":"https://s26.postimg.org/3n85yisu1/one_5_51_58_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/65tuz7ek9/two_5_41_53_PM.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/7ywrnizqx/three_5_41_53_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/6l54s80hl/four.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/ioagfsbjt/five.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/65tuz7ek9/two_5_41_53_PM.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/7ywrnizqx/three_5_41_53_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/6l54s80hl/four.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/ioagfsbjt/five.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/3n85yisu1/one_5_51_58_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/65tuz7ek9/two_5_41_53_PM.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/7ywrnizqx/three_5_41_53_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/6l54s80hl/four.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/ioagfsbjt/five.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/65tuz7ek9/two_5_41_53_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/7ywrnizqx/three_5_41_53_PM.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/6l54s80hl/four.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/ioagfsbjt/five.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/3n85yisu1/one_5_51_58_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/65tuz7ek9/two_5_41_53_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/7ywrnizqx/three_5_41_53_PM.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/6l54s80hl/four.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/ioagfsbjt/five.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/65tuz7ek9/two_5_41_53_PM.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/7ywrnizqx/three_5_41_53_PM.png", "like":"1"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/6l54s80hl/four.png", "like":"0"])
        arrayImageOptions.append(["image":"https://s26.postimg.org/ioagfsbjt/five.png", "like":"0"])
    }
}
