//
//  ActivityIndicator.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.
//

import Foundation
import UIKit

var container: UIView = UIView()
var loadingView: UIView = UIView()

var activityIndicator: UIActivityIndicatorView!

class ActivityIndicator{
    //MARK: TableFooter Indicator
    func E_footerShow(tableView:UITableView) -> UIView{
        
        if activityIndicator != nil && activityIndicator.isAnimating == true {
            hiddeActivityIndicator()
        }
        let noData = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(tableView.bounds.size.width), height: CGFloat(30)))
        activityIndicator           = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        activityIndicator.color     = UIColor.white
        noData.addSubview(activityIndicator)
        activityIndicator.center    = CGPoint(x: CGFloat(noData.frame.size.width / 2), y: CGFloat(noData.frame.size.height / 2))
        activityIndicator.startAnimating()
        noData.backgroundColor      = Comman().UIColorFromRGB(rgbValue: 0x3FB9AF, alpha: 1.0)
        noData.layer.cornerRadius   = 3
        return noData
    }
    
    func E_footerDismiss(tableView:UITableView) ->UIView?{
        hiddeActivityIndicator()
        return nil
    }
}

//MARK: Show Activity
func showActivityIndicator(uiView: UIView) {
    
    if activityIndicator != nil && activityIndicator.isAnimating == true {
        hiddeActivityIndicator()
    }
    activityIndicator = UIActivityIndicatorView(frame: CGRect(x:0.0, y:0.0, width:100.0, height:100.0))
    activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
    activityIndicator.center = CGPoint(x:uiView.frame.size.width / 2, y:uiView.frame.size.height / 2);
    activityIndicator.hidesWhenStopped = true
    uiView.addSubview(activityIndicator)
    activityIndicator.startAnimating()
    uiView.bringSubview(toFront: activityIndicator)
}

//MARK: Hidde Activity
func hiddeActivityIndicator() {
    if((activityIndicator) != nil){
        activityIndicator.isHidden = true
        activityIndicator.removeFromSuperview()
    }
}

//MARK: Extra Activity Indigator
func showProgress(uiView: UIView) {
    
    container.frame = uiView.frame
    container.center = uiView.center
    container.backgroundColor = UIColorFromHex(rgbValue: 0xffffff, alpha: 0.3)
    
    loadingView.frame = CGRect(x:0, y:0, width:80, height:80)
    loadingView.center = uiView.center
    loadingView.backgroundColor = UIColorFromHex(rgbValue: 0xccebff, alpha: 0.7)
    loadingView.clipsToBounds = true
    loadingView.layer.cornerRadius = 10
    
    if activityIndicator != nil && activityIndicator.isAnimating == true {
        dismissProgress()
    }
    activityIndicator = UIActivityIndicatorView(frame: CGRect(x:0.0, y:0.0, width:40.0, height:40.0))
    activityIndicator.frame = CGRect(x: 0.0, y: 0.0, width: 40.0, height: 40.0)
    activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
    activityIndicator.center = CGPoint(x:loadingView.frame.size.width / 2, y:loadingView.frame.size.height / 2);
    activityIndicator.color = UIColor.yellow    //UIColorFromHex(rgbValue: 0x001f33, alpha: 1)
    activityIndicator.hidesWhenStopped = true
    
    loadingView.addSubview(activityIndicator)
    container.addSubview(loadingView)
    uiView.addSubview(container)
    activityIndicator.startAnimating()
}

/*
 Hide activity indicator
 Actually remove activity indicator from its super view
 @param uiView - remove activity indicator from this view
 */
func dismissProgress() {
    activityIndicator.stopAnimating()
    container.removeFromSuperview()
}

/*
 Define UIColor from hex value
 @param rgbValue - hex color value
 @param alpha - transparency level
 */
func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
    let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
    let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
    let blue = CGFloat(rgbValue & 0xFF)/256.0
    return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
}

