//
//  FeedListVC.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.//

import UIKit

class FeedListVC: UIViewController {

    @IBOutlet weak var scrollButton: UIButton!
    @IBOutlet weak var tblFeedList: UITableView!
    let numberOfRow = 15
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblFeedList.tableFooterView = ActivityIndicator().E_footerShow(tableView: tblFeedList)
        Comman().animateButton(button: scrollButton)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        super.viewWillAppear(animated)
    }

}

//MARK: IBAction
extension FeedListVC {

    @IBAction func btnScrollBottom(_ sender: AnyObject) {
        
        Comman().animateButton(button: scrollButton)
        if(self.tblFeedList.tableFooterView == nil){
            let ipath = IndexPath(row: numberOfRow-1 , section: 0)
            self.tblFeedList.scrollToRow(at: ipath, at: .top, animated: true)
            self.tblFeedList.tableFooterView = ActivityIndicator().E_footerShow(tableView: tblFeedList)
        }else{
            self.tblFeedList.tableFooterView = ActivityIndicator().E_footerDismiss(tableView: tblFeedList)
        }
    }
    
    @IBAction func btnEditProfile(_ sender: AnyObject) {
        
        let objSignUp = RegistrationVC(nibName:"RegistrationVC",bundle: nil)
        objSignUp.isEditable = objSignUp.giveEdit()
        self.navigationController?.pushViewController(objSignUp, animated: true)
        
    }
}

//MARK: TableView Methods
extension FeedListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return numberOfRow
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell:UITableViewCell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Cell")
        cell.textLabel?.text        = "Title"
        cell.detailTextLabel?.text  = "Desription"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        let objSignUp = RegistrationVC(nibName:"RegistrationVC",bundle: nil)
        objSignUp.isEditable = objSignUp.giveNew()
        self.navigationController?.pushViewController(objSignUp, animated: true)
    }
}
