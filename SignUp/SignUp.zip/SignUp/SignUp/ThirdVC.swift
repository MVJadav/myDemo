//
//  ThirdVC.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.//

import UIKit
import SafariServices

class ThirdVC: UIViewController, SFSafariViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        super.viewWillAppear(animated)
    }

}

//MARK: IBAction
extension ThirdVC {
    
    @IBAction func imageSlider(_ sender: AnyObject) {
        let objImageCollectionVC = ImageCollectionVC(nibName:"ImageCollectionVC",bundle: nil)
        self.navigationController?.pushViewController(objImageCollectionVC, animated: true)
    }
    
    @IBAction func showActionSheet(_ sender: AnyObject) {
        getActionSheet()
    }

    @IBAction func alertViewController(_ sender: AnyObject) {
        let str:String = "Your Safari Item is listed \n successfully!Your Safari Item is listed "
        AlertViewController.showAlertController(alertImg: "safari", alertTitle: "Your Title", alertMessage: str) { (completionHandler) in
            
            switch completionHandler{
            case .yes:
                self.AlertMessage(msg: "You have selected Yes")
                break
            case .no:
                self.AlertMessage(msg: "You have selected No")
                break
                //default: break
            }
        }
    }
    
    @IBAction func successAlert(_ sender: AnyObject) {
        let str:String = "Your Comment Item is listed \n successfully! Your Comment is listed "
        AlertViewController.showAlertControllerSuccess(alertImg: "comment", alertMessage: str) { (completionHandler) in
            //code
            switch completionHandler{
            case .yes:
                break
            default: break
            }
        }
    }
    
    @IBAction func datePicker(_ sender: AnyObject) {
        DatePickerController.showDatePicker(displayDate: "", dateFormat: "", dateWithTime: false) {
            (date) in
            self.AlertMessage(msg: "Date: "+date)
        }
    }
    
    @IBAction func pickerController(_ sender: AnyObject) {
        let arr = ["Apple", "Apricot", "Avocado", "Banana", "Bilberry", "Blackberry", "Blackcurrant", "Blueberry"]
        PickerController.showPicker(pickerArray: arr, selectedPicker: "Avocado") { (result, index) in
            //code
            self.AlertMessage(msg: result+" : "+String(index))
        }
    }

}

//MARK: Other Methods
extension ThirdVC {
    
    func getActionSheet(){
        let arrAcationSheetData: [[String: String]] = [
            [ActionKey.Title: ActionSheetData.strSafari, ActionKey.SubTitle: ActionSheetData.strSubTitleSafari, ActionKey.Image: ActionSheetData.imgSafari],
            [ActionKey.Title: ActionSheetData.strComment, ActionKey.SubTitle: ActionSheetData.strSubTitleComment, ActionKey.Image: ActionSheetData.imgComment],
            [ActionKey.Title: ActionSheetData.strTweet, ActionKey.SubTitle: ActionSheetData.strSubTitleTweet, ActionKey.Image: ActionSheetData.imgTweet],
            [ActionKey.Title: ActionSheetData.strSafari, ActionKey.SubTitle: ActionSheetData.strSubTitleSafari, ActionKey.Image: ActionSheetData.imgSafari],
            [ActionKey.Title: ActionSheetData.strComment, ActionKey.SubTitle: ActionSheetData.strSubTitleComment, ActionKey.Image: ActionSheetData.imgComment],
            [ActionKey.Title: ActionSheetData.strTweet, ActionKey.SubTitle: ActionSheetData.strSubTitleTweet, ActionKey.Image: ActionSheetData.imgTweet]
        ]
        ActionSheetVC.showActionSheetWithOption(optionToDisplay: arrAcationSheetData) { (completionHandler) in
            //code
            switch completionHandler {
            case .Safari:
                self.AlertMessage(msg: ""+ActionSheetData.strSafari)
                break
            case .Comment:
                self.AlertMessage(msg: ""+ActionSheetData.strComment)
                break
            case .Tweet:
                self.AlertMessage(msg: ""+ActionSheetData.strTweet)
                break
                //default: break
            }
        }
    }
    
    //Alert Function
    func AlertMessage(msg:String){
        
        let alertController = UIAlertController(title: "Action", message: msg, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (result : UIAlertAction) -> Void in
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
}
