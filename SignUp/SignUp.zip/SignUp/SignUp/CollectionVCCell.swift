//
//  CollectionVCCell.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.
//

import UIKit

class CollectionVCCell: UICollectionViewCell {

    @IBOutlet weak var lblTitle         : UILabel!
    @IBOutlet weak var imgCollection    : UIImageView!
    @IBOutlet weak var likeButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func initObject(imageArray: Dictionary<String,String>, indexPath: IndexPath){
        likeButton.superview?.tag     = indexPath.row
        let url:URL = URL(string: imageArray["image"]!)!
        imgCollection.af_setImage(withURL: url, placeholderImage: UIImage(named:"ic_user"), filter: nil, progress: { (Progress) in
        }, runImageTransitionIfCached: true) { (image) in }
        lblTitle.text = "Sort Description"
    }
}
